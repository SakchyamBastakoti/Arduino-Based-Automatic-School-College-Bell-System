Readme file for DS1307RTC Library

The DS1307RTC library is provided to demonstrate the Arduino Time library.

See the TimeRTC example sketches privided with the Time library download for usage


